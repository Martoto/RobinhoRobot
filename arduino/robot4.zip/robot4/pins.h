#define HIGH 1
#define LOW 0

#define servo 11

#define m1p1 5
#define m1p2 6
#define m2p1 10
#define m2p2 9

//?
#define m1e 2
#define m2e 3