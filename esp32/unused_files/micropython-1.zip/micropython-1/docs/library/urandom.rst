:mod:`urandom` -- pseudo-random number generation
=================================================

.. module:: urandom
   :synopsis: pseudo-random number generation

|see_cpython_module| :mod:`python:random`.

Functions
---------

.. function:: getrandbits(num_bits)

.. function:: seed(value)
