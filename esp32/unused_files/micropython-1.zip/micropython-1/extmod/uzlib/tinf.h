/* Compatibility header for the original tinf lib/older versions of uzlib.
   Note: may be removed in the future, please migrate to uzlib.h. */
#include "uzlib.h"
